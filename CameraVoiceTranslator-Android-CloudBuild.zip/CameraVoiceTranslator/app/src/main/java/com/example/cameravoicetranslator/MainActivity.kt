package com.example.cameravoicetranslator

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), TextToSpeech.OnInitListener {
    private lateinit var previewView: PreviewView
    private lateinit var sourceText: TextView
    private lateinit var translatedText: TextView
    private lateinit var statusText: TextView
    private lateinit var speakButton: Button
    private lateinit var tts: TextToSpeech

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val languageIdentifier = LanguageIdentification.getClient()
    private val busy = AtomicBoolean(false)

    private var translator: Translator? = null
    private var lastSource = ""
    private var lastTranslation = ""
    private var ttsReady = false
    private var lastProcessedAt = 0L

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) startCamera()
            else statusText.text = "ต้องอนุญาตใช้กล้องเพื่อเริ่มแปลภาษา"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera() else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 16)
            setBackgroundColor(0xFF101820.toInt())
        }

        val title = TextView(this).apply {
            text = "Camera Voice Translator"
            textSize = 22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        statusText = TextView(this).apply {
            text = "กำลังเตรียมกล้อง..."
            textSize = 14f
            setTextColor(0xFFB8C7D1.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 12)
        }
        previewView = PreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1.0f
            )
            scaleType = PreviewView.ScaleType.FILL_CENTER
        }

        val sourceLabel = label("อ่านข้อความที่พบ")
        sourceText = contentBox("หันกล้องไปยังข้อความภาษาต่างประเทศ")
        val targetLabel = label("คำแปลภาษาไทย")
        translatedText = contentBox("คำแปลจะแสดงตรงนี้")

        speakButton = Button(this).apply {
            text = "🔊 ฟังเสียงคำแปล"
            isEnabled = false
            setOnClickListener {
                if (lastTranslation.isNotBlank()) {
                    tts.language = Locale.forLanguageTag("th-TH")
                    tts.speak(lastTranslation, TextToSpeech.QUEUE_FLUSH, null, "thai_translation")
                }
            }
        }

        root.addView(title)
        root.addView(statusText)
        root.addView(previewView)
        root.addView(sourceLabel)
        root.addView(sourceText)
        root.addView(targetLabel)
        root.addView(translatedText)
        root.addView(speakButton)
        setContentView(root)
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 14f
        setTextColor(0xFF73D6A4.toInt())
        setPadding(0, 10, 0, 4)
    }

    private fun contentBox(value: String) = TextView(this).apply {
        text = value
        textSize = 17f
        setTextColor(0xFFFFFFFF.toInt())
        setBackgroundColor(0xFF263746.toInt())
        setPadding(12, 12, 12, 12)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            analysis.setAnalyzer(cameraExecutor) { imageProxy -> analyzeFrame(imageProxy) }

            try {
                provider.unbindAll()
                provider.bindToLifecycle(
                    this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis
                )
                statusText.text = "กำลังสแกนข้อความ • แปลเป็นภาษาไทย"
            } catch (e: Exception) {
                statusText.text = "เปิดกล้องไม่สำเร็จ: ${e.localizedMessage}"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (busy.get() || now - lastProcessedAt < 900) {
            proxy.close()
            return
        }
        val mediaImage = proxy.image
        if (mediaImage == null) {
            proxy.close()
            return
        }
        busy.set(true)
        lastProcessedAt = now

        val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
        recognizer.process(image)
            .addOnSuccessListener { result ->
                val text = result.text
                    .lineSequence()
                    .map { it.trim() }
                    .filter { it.isNotBlank() }
                    .take(8)
                    .joinToString("\n")
                    .take(1200)

                if (text.isNotBlank() && text != lastSource) {
                    lastSource = text
                    runOnUiThread {
                        sourceText.text = text
                        translatedText.text = "กำลังแปล..."
                        speakButton.isEnabled = false
                    }
                    identifyAndTranslate(text)
                }
            }
            .addOnFailureListener { /* Ignore one bad frame and continue scanning. */ }
            .addOnCompleteListener {
                proxy.close()
                busy.set(false)
            }
    }

    private fun identifyAndTranslate(text: String) {
        languageIdentifier.identifyLanguage(text)
            .addOnSuccessListener { languageCode ->
                if (languageCode == "und") {
                    showStatus("ตรวจจับภาษาไม่สำเร็จ ลองขยับกล้องหรือเพิ่มแสง")
                    return@addOnSuccessListener
                }
                val source = TranslateLanguage.fromLanguageTag(languageCode)
                val thai = TranslateLanguage.THAI
                if (source == null) {
                    showTranslationError("ยังไม่รองรับภาษานี้ ($languageCode)")
                    return@addOnSuccessListener
                }
                if (source == thai) {
                    showTranslation(text)
                    return@addOnSuccessListener
                }
                val options = TranslatorOptions.Builder()
                    .setSourceLanguage(source)
                    .setTargetLanguage(thai)
                    .build()
                translator?.close()
                translator = Translation.getClient(options)
                showStatus("กำลังเตรียมโมเดลภาษา...")
                translator?.downloadModelIfNeeded()
                    ?.addOnSuccessListener {
                        translator?.translate(text)
                            ?.addOnSuccessListener { translated -> showTranslation(translated) }
                            ?.addOnFailureListener { showTranslationError("แปลไม่สำเร็จ ตรวจสอบอินเทอร์เน็ต") }
                    }
                    ?.addOnFailureListener {
                        showTranslationError("ดาวน์โหลดโมเดลภาษาไม่สำเร็จ กรุณาเชื่อมต่ออินเทอร์เน็ต")
                    }
            }
            .addOnFailureListener { showTranslationError("ตรวจจับภาษาไม่สำเร็จ") }
    }

    private fun showTranslation(value: String) {
        lastTranslation = value
        runOnUiThread {
            translatedText.text = value
            speakButton.isEnabled = value.isNotBlank() && ttsReady
            statusText.text = "แปลเสร็จแล้ว • ส่องข้อความอื่นต่อได้เลย"
        }
    }

    private fun showTranslationError(message: String) {
        runOnUiThread {
            translatedText.text = message
            statusText.text = "พร้อมสแกนอีกครั้ง"
        }
    }

    private fun showStatus(message: String) {
        runOnUiThread { statusText.text = message }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (ttsReady) {
            val result = tts.setLanguage(Locale.forLanguageTag("th-TH"))
            runOnUiThread {
                speakButton.isEnabled = lastTranslation.isNotBlank() &&
                    result != TextToSpeech.LANG_MISSING_DATA &&
                    result != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        recognizer.close()
        languageIdentifier.close()
        translator?.close()
        tts.stop()
        tts.shutdown()
    }
}
